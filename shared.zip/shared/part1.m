function [f] = part1(m,Y,E,A)
% bilinearity influence
coeff = 0.00001;
[bands,pixels] = size(Y);
D = zeros(bands,m*(m-1)/2);
B = zeros(m*(m-1)/2,pixels); 
E(find(E<=0))=1e-9;% avoid negtive values and zeros
  for j=1:bands
      E2=bsxfun(@times,E(j,:),E(j,:)');
      E3=tril(E2,-1);
      d0=E3(E3~=0);
      D(j,:)=d0;
  end
    B(:,sum(B)==0) = eps;% avoid to bring nan.
    Y2 = abs(Y-E*A); 
    Y_Eplus = (abs(Y2'*D)+Y2'*D)/2;
    Y_Eminus = (abs(Y2'*D)-Y2'*D)/2;
    Eplus = (abs(D'*D)+D'*D)/2;
    Eminus = (abs(D'*D)-D'*D)/2;
    B = (B'.*(sqrt((Y_Eplus+B'*Eminus)./(Y_Eminus+B'*Eplus))))';
    
    for i1 = 1:pixels
        a = A(:,i1);
        b = (triu(a*a')-diag(diag(a*a'))+tril(ones(size(a,1)))*(-1))';
        B(:,i1) = b(b~=-1);
    end
  B = B*coeff;
  f = sqrt(sum(sum((Y-E*A-D*B).^2))/(bands*pixels));
end